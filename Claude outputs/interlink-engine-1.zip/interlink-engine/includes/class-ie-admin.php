<?php
/**
 * The screens.
 *
 * Two: a connection screen, and a campaigns screen that does everything else.
 * Deliberately plain — this is the shape working, not the visual design. The
 * information architecture is the part worth getting right now, because it is
 * the part that is expensive to change later.
 *
 * THE FLOW THAT MATTERS
 *
 * Planning refuses a topic without a target query, and refuses the whole
 * campaign if any query would compete with the page it is meant to feed. So
 * the owner must not meet that refusal cold. Two paths lead into planning:
 *
 *   "Suggest topics"   the server proposes them, complete, ready to edit
 *   "Use my own"       the server derives the missing fields from what was
 *                      typed, and reports anything it is unhappy about
 *
 * Both are free and rate limited. Someone deciding whether this is worth
 * buying should not be charged to find out.
 *
 * @package interlink-engine
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class IE_Admin {

	/** Where a draft set of topics lives between the two steps. */
	const DRAFT_TRANSIENT = 'ie_draft_topics_';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_ie_connect', array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_ie_suggest', array( __CLASS__, 'handle_suggest' ) );
		add_action( 'admin_post_ie_create_campaign', array( __CLASS__, 'handle_create_campaign' ) );
		add_action( 'admin_post_ie_run_now', array( __CLASS__, 'handle_run_now' ) );
		add_action( 'admin_post_ie_publish_now', array( __CLASS__, 'handle_publish_now' ) );
		add_action( 'admin_post_ie_delete_campaign', array( __CLASS__, 'handle_delete_campaign' ) );
		add_action( 'admin_post_ie_discard_draft', array( __CLASS__, 'handle_discard_draft' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'Interlink Engine', 'interlink-engine' ),
			__( 'Interlink', 'interlink-engine' ),
			'manage_options',
			'interlink-engine',
			array( __CLASS__, 'render_campaigns' ),
			'dashicons-admin-links',
			58
		);

		add_submenu_page(
			'interlink-engine',
			__( 'Campaigns', 'interlink-engine' ),
			__( 'Campaigns', 'interlink-engine' ),
			'manage_options',
			'interlink-engine',
			array( __CLASS__, 'render_campaigns' )
		);

		add_submenu_page(
			'interlink-engine',
			__( 'Connection', 'interlink-engine' ),
			__( 'Connection', 'interlink-engine' ),
			'manage_options',
			'interlink-connection',
			array( __CLASS__, 'render_connection' )
		);
	}

	/* --------------------------------------------------------------------
	 * Connection
	 * ----------------------------------------------------------------- */

	public static function render_connection() {
		$connected = IE_Settings::is_connected();
		$credits   = IE_Settings::credits();
		$per_post  = IE_Settings::credits_per_post();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Connection', 'interlink-engine' ); ?></h1>

			<?php self::notices(); ?>

			<?php if ( $connected ) : ?>
				<p>
					<strong><?php esc_html_e( 'Connected.', 'interlink-engine' ); ?></strong>
					<?php if ( null !== $credits ) : ?>
						<?php
						printf(
							/* translators: 1: credit balance, 2: cost of one post */
							esc_html__( '%1$s credits available, %2$s per post.', 'interlink-engine' ),
							esc_html( number_format_i18n( $credits ) ),
							esc_html( null === $per_post ? '—' : number_format_i18n( $per_post ) )
						);
						?>
					<?php endif; ?>
					<?php
					// The build, on the screen the owner is already looking at
					// when something is wrong. The plugins list has it too, but
					// nobody thinks to go there — and "which version is this?"
					// is the first question worth answering when a site and a
					// server disagree about what an endpoint is called.
					?>
					<span class="description" style="margin-left:.5rem">
						<?php echo esc_html( sprintf( __( 'Plugin v%s', 'interlink-engine' ), IE_VERSION ) ); ?>
					</span>
				</p>
				<p class="description">
					<?php esc_html_e( 'Your licence key is not stored here — it was exchanged for a signing key at connection. To move this site to another account, paste a new key below.', 'interlink-engine' ); ?>
				</p>
			<?php else : ?>
				<p><?php esc_html_e( 'Paste the licence key from your account. No API keys are needed — the writing happens on our servers.', 'interlink-engine' ); ?></p>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="ie_connect">
				<?php wp_nonce_field( 'ie_connect' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="ie_licence"><?php esc_html_e( 'Licence key', 'interlink-engine' ); ?></label></th>
						<td>
							<input name="licence_key" id="ie_licence" type="text" class="regular-text"
								autocomplete="off" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX">
							<?php if ( $connected ) : ?>
								<p class="description">
									<?php esc_html_e( 'Leave blank unless you are moving this site to another account. Saving with this empty changes only the server address.', 'interlink-engine' ); ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ie_server"><?php esc_html_e( 'Server', 'interlink-engine' ); ?></label></th>
						<td>
							<input name="server_url" id="ie_server" type="url" class="regular-text"
								value="<?php echo esc_attr( IE_Settings::server_url() ); ?>">
							<p class="description"><?php esc_html_e( 'Leave this alone unless you were told otherwise. Changing it on its own is safe — it will not disconnect the site.', 'interlink-engine' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'This site reports', 'interlink-engine' ); ?></th>
						<td>
							<p class="description">
								<?php echo esc_html( home_url() ); ?><br>
								<?php echo esc_html( wp_timezone_string() ); ?>
								<?php esc_html_e( '— posts are scheduled in this timezone.', 'interlink-engine' ); ?>
							</p>
						</td>
					</tr>
				</table>
				<?php
				// "Save" rather than "Reconnect" once connected, because with
				// an empty licence key that is what it does. A button labelled
				// Reconnect on a form whose usual use is editing one address
				// promises something alarming and does something ordinary.
				submit_button( $connected ? __( 'Save', 'interlink-engine' ) : __( 'Connect', 'interlink-engine' ) );
				?>
			</form>

			<h2><?php esc_html_e( 'Recent activity', 'interlink-engine' ); ?></h2>
			<?php self::render_log(); ?>
		</div>
		<?php
	}

	/**
	 * Save the connection settings.
	 *
	 * TWO DIFFERENT ACTIONS BEHIND ONE BUTTON, and separating them is the
	 * whole point of this function.
	 *
	 * With a licence key, this is an activation: the key is exchanged for a
	 * site id and a signing secret, and the old ones stop working.
	 *
	 * WITHOUT a licence key, on a site that is already connected, it is just
	 * an address change — and it must not touch the connection. It used to:
	 * the form always called activate(), activate() clears the site id and
	 * secret when it fails, and the key is never stored here, so an owner who
	 * corrected the server address and pressed Save disconnected their site.
	 * A working site should not be one keystroke from being unreachable
	 * because someone edited a URL.
	 */
	public static function handle_connect() {
		check_admin_referer( 'ie_connect' );
		self::require_caps();

		$key    = isset( $_POST['licence_key'] ) ? sanitize_text_field( wp_unslash( $_POST['licence_key'] ) ) : '';
		$server = isset( $_POST['server_url'] ) ? esc_url_raw( wp_unslash( $_POST['server_url'] ) ) : '';

		/* ---- address only ---- */

		if ( '' === $key && IE_Settings::is_connected() ) {
			$host = $server ? wp_parse_url( $server, PHP_URL_HOST ) : '';

			if ( ! $host ) {
				self::redirect( 'interlink-connection', 'error',
					__( 'That does not look like a web address. It should start with https://', 'interlink-engine' ) );
			}

			if ( untrailingslashit( $server ) === IE_Settings::server_url() ) {
				self::redirect( 'interlink-connection', 'unchanged', '' );
			}

			IE_Settings::set( array( 'server_url' => untrailingslashit( $server ) ) );

			IE_Publisher::log( sprintf( 'server address changed to %s', untrailingslashit( $server ) ) );

			self::redirect( 'interlink-connection', 'server_saved', '' );
		}

		/* ---- a real activation ---- */

		if ( '' === $key ) {
			self::redirect( 'interlink-connection', 'error',
				__( 'Paste your licence key to connect this site.', 'interlink-engine' ) );
		}

		$result = IE_Api::activate( $key, $server );

		self::redirect(
			'interlink-connection',
			is_wp_error( $result ) ? 'error' : 'connected',
			is_wp_error( $result ) ? $result->get_error_message() : ''
		);
	}

	/* --------------------------------------------------------------------
	 * Campaigns
	 * ----------------------------------------------------------------- */

	public static function render_campaigns() {
		$campaigns = IE_Campaigns::all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Campaigns', 'interlink-engine' ); ?></h1>

			<?php self::notices(); ?>

			<?php if ( ! IE_Settings::is_connected() ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					printf(
						wp_kses_post( __( 'Connect your licence key first — <a href="%s">Connection</a>.', 'interlink-engine' ) ),
						esc_url( admin_url( 'admin.php?page=interlink-connection' ) )
					);
					?>
				</p></div>
				</div>
				<?php
				return;
			endif;
			?>

			<?php self::render_upcoming(); ?>

			<?php
			/**
			 * Finished campaigns move out of the way.
			 *
			 * A campaign whose posts are all published needs nothing from
			 * anyone, and after a year there will be more finished ones than
			 * live ones. Keeping them in the main list buries the campaigns
			 * that still need decisions under the ones that do not.
			 */
			$live = array();
			$done = array();

			foreach ( $campaigns as $campaign ) {
				$outstanding = 0;
				foreach ( $campaign['slots'] as $slot ) {
					if ( 'published' !== $slot['status'] ) {
						$outstanding++;
					}
				}
				if ( $outstanding ) {
					$live[] = $campaign;
				} else {
					$done[] = $campaign;
				}
			}

			// Collapsed by default once there is more than one to read. A
			// single campaign has nothing to be buried under, so it opens.
			$collapse = count( $live ) > 1;
			?>

			<?php foreach ( $live as $campaign ) : ?>
				<?php self::render_campaign_card( $campaign, $collapse ); ?>
			<?php endforeach; ?>

			<?php if ( $done ) : ?>
				<details style="margin:1.5rem 0">
					<summary style="cursor:pointer;font-weight:600">
						<?php
						echo esc_html( sprintf(
							/* translators: %d: number of finished campaigns */
							_n( '%d finished campaign', '%d finished campaigns', count( $done ), 'interlink-engine' ),
							count( $done )
						) );
						?>
					</summary>
					<div style="margin-top:1rem">
						<?php foreach ( $done as $campaign ) : ?>
							<?php self::render_campaign_card( $campaign, true ); ?>
						<?php endforeach; ?>
					</div>
				</details>
			<?php endif; ?>

			<?php if ( empty( $campaigns ) ) : ?>
				<p><?php esc_html_e( 'No campaigns yet. A campaign is a batch of posts, all feeding one page you want to rank.', 'interlink-engine' ); ?></p>
			<?php endif; ?>

			<hr>
			<h2><?php esc_html_e( 'New campaign', 'interlink-engine' ); ?></h2>
			<?php self::render_new_campaign_form(); ?>
		</div>
		<?php
	}

	/**
	 * What is publishing next, across every campaign.
	 *
	 * The one view a campaign card cannot give you, because a card only knows
	 * its own dates. Put at the top because it answers the question an owner
	 * opens this screen to ask.
	 */
	private static function render_upcoming() {
		$rows       = IE_Campaigns::upcoming( 10 );
		$collisions = IE_Campaigns::collisions();

		if ( empty( $rows ) ) {
			return;
		}

		$today = wp_date( 'Y-m-d' );
		?>
		<h2 style="margin-top:1.5rem"><?php esc_html_e( 'Coming up', 'interlink-engine' ); ?></h2>

		<?php if ( $collisions ) : ?>
			<div class="notice notice-warning inline" style="margin:0 0 1rem"><p>
				<?php
				echo esc_html( sprintf(
					/* translators: 1: number of days, 2: the first such date */
					_n(
						'Two posts land on the same day (%2$s). A blog that publishes once a week and then twice at once reads as automated — consider shifting one campaign\'s time.',
						'Several days carry more than one post (%1$d of them, first on %2$s). A blog that publishes once a week and then twice at once reads as automated — consider shifting one campaign\'s time.',
						count( $collisions ),
						'interlink-engine'
					),
					count( $collisions ),
					wp_date( 'j M', strtotime( array_key_first( $collisions ) ) )
				) );
				?>
			</p></div>
		<?php endif; ?>

		<table class="widefat striped" style="margin-bottom:1.5rem">
			<thead>
				<tr>
					<th style="width:12rem"><?php esc_html_e( 'When', 'interlink-engine' ); ?></th>
					<th><?php esc_html_e( 'Post', 'interlink-engine' ); ?></th>
					<th style="width:16rem"><?php esc_html_e( 'Feeding', 'interlink-engine' ); ?></th>
					<th style="width:10rem"><?php esc_html_e( 'State', 'interlink-engine' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $rows as $row ) : ?>
				<?php
				$day     = wp_date( 'Y-m-d', $row['at'] );
				$clashes = isset( $collisions[ $day ] );
				?>
				<tr>
					<td>
						<?php echo esc_html( wp_date( 'j M, H:i', $row['at'] ) ); ?>
						<?php if ( $day === $today ) : ?>
							<strong style="color:#2271b1"><?php esc_html_e( '· today', 'interlink-engine' ); ?></strong>
						<?php endif; ?>
						<?php if ( $clashes ) : ?>
							<span title="<?php esc_attr_e( 'Another post publishes the same day', 'interlink-engine' ); ?>"
							      style="color:#b26200">&#9888;</span>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( $row['post_id'] ) : ?>
							<a href="<?php echo esc_url( get_edit_post_link( $row['post_id'] ) ); ?>">
								<?php echo esc_html( $row['topic'] ); ?>
							</a>
						<?php else : ?>
							<?php echo esc_html( $row['topic'] ); ?>
						<?php endif; ?>
					</td>
					<td class="description"><?php echo esc_html( $row['page'] ); ?></td>
					<td>
						<?php if ( $row['overdue'] ) : ?>
							<?php // Scheduled, date passed, still not public. WP-Cron has not run. ?>
							<strong style="color:#b32d2e"><?php esc_html_e( 'overdue', 'interlink-engine' ); ?></strong>
						<?php elseif ( 'scheduled' === $row['status'] ) : ?>
							<span style="color:#2271b1"><?php esc_html_e( 'scheduled', 'interlink-engine' ); ?></span>
						<?php elseif ( 'failed' === $row['status'] ) : ?>
							<span style="color:#b32d2e"><?php esc_html_e( 'failed', 'interlink-engine' ); ?></span>
						<?php else : ?>
							<span style="color:#777"><?php esc_html_e( 'not written yet', 'interlink-engine' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	private static function render_campaign_card( $campaign, $collapse = false ) {
		// Two numbers now, because a post being ON the site and a post being
		// VISIBLE are no longer the same event. "9 of 12 scheduled, 3 live"
		// is the sentence the owner needs; one combined figure hides whichever
		// half they were actually asking about.
		$scheduled = 0;
		$live      = 0;

		foreach ( $campaign['slots'] as $slot ) {
			if ( 'published' === $slot['status'] ) {
				$live++;
				$scheduled++;
			} elseif ( 'scheduled' === $slot['status'] ) {
				$scheduled++;
			}
		}

		$orphans = IE_Campaigns::orphans( $campaign );
		?>
		<div class="card" style="max-width:none;padding:1rem 1.25rem;margin-bottom:1.25rem">
			<h2 style="margin-top:0">
				<?php echo esc_html( $campaign['label'] ? $campaign['label'] : $campaign['target_page']['title'] ); ?>
				<span style="font-weight:400;color:#666">
					— <?php echo esc_html( sprintf(
						/* translators: 1: posts on the site, 2: total, 3: how many are public */
						__( '%1$d of %2$d scheduled, %3$d live', 'interlink-engine' ),
						$scheduled, count( $campaign['slots'] ), $live
					) ); ?>,
					<?php echo esc_html( 'draft' === $campaign['publish_mode'] ? __( 'saving as drafts', 'interlink-engine' ) : __( 'publishing on schedule', 'interlink-engine' ) ); ?>
				</span>
			</h2>

			<p style="margin-top:0">
				<?php esc_html_e( 'Feeding:', 'interlink-engine' ); ?>
				<a href="<?php echo esc_url( $campaign['target_page']['url'] ); ?>" target="_blank" rel="noreferrer">
					<?php echo esc_html( $campaign['target_page']['title'] ); ?>
				</a>
				&middot; <?php echo esc_html( sprintf( __( 'every %d days', 'interlink-engine' ), (int) $campaign['every_days'] ) ); ?>
				<?php if ( ! empty( $campaign['quote']['total'] ) ) : ?>
					&middot; <?php echo esc_html( sprintf( __( '%s credits for the batch', 'interlink-engine' ), number_format_i18n( $campaign['quote']['total'] ) ) ); ?>
				<?php endif; ?>
			</p>

			<?php if ( ! empty( $orphans ) ) : ?>
				<div class="notice notice-warning inline"><p>
					<?php
					printf(
						esc_html__( 'Nothing links to slot(s): %s. The ring has been broken by an edit.', 'interlink-engine' ),
						esc_html( implode( ', ', $orphans ) )
					);
					?>
				</p></div>
			<?php endif; ?>

			<?php
			/**
			 * The slot table folds away once there is more than one campaign.
			 *
			 * Twelve rows per campaign is fine to read when there is one. At
			 * four campaigns it is forty-eight rows of scrolling between an
			 * owner and the button they came to press — and the per-slot
			 * detail is rarely what they came for, because "Coming up" at the
			 * top already answers the usual question.
			 *
			 * <details> rather than JavaScript: it survives a page with no
			 * scripts, keeps its own state, and is searchable by the browser's
			 * find on modern engines.
			 */
			?>
			<details <?php echo $collapse ? '' : 'open'; ?>>
				<summary style="cursor:pointer;margin:.5rem 0;color:#2271b1">
					<?php
					echo esc_html( sprintf(
						/* translators: %d: number of posts in the campaign */
						_n( 'Show the %d post', 'Show all %d posts', count( $campaign['slots'] ), 'interlink-engine' ),
						count( $campaign['slots'] )
					) );
					?>
				</summary>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Topic', 'interlink-engine' ); ?></th>
						<th><?php esc_html_e( 'Targets', 'interlink-engine' ); ?></th>
						<th><?php esc_html_e( 'Due', 'interlink-engine' ); ?></th>
						<th><?php esc_html_e( 'State', 'interlink-engine' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $campaign['slots'] as $slot ) : ?>
					<tr>
						<td>
							<?php if ( $slot['post_id'] ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $slot['post_id'] ) ); ?>"><?php echo esc_html( $slot['topic'] ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $slot['topic'] ); ?>
							<?php endif; ?>
						</td>
						<td><code><?php echo esc_html( $slot['target_query'] ); ?></code></td>
						<td>
							<?php
							echo esc_html(
								$slot['publish_at']
									? wp_date( 'j M Y, H:i', strtotime( $slot['publish_at'] ) )
									: '—'
							);
							?>
						</td>
						<td>
							<?php if ( 'published' === $slot['status'] ) : ?>
								<span style="color:#1a7f37">&#10003; <?php esc_html_e( 'live', 'interlink-engine' ); ?></span>
							<?php elseif ( 'scheduled' === $slot['status'] ) : ?>
								<?php // On the site with a real permalink, not yet public. ?>
								<span style="color:#2271b1">&#128337; <?php esc_html_e( 'scheduled', 'interlink-engine' ); ?></span>
							<?php elseif ( $slot['error'] ) : ?>
								<span style="color:#b32d2e" title="<?php echo esc_attr( $slot['error'] ); ?>">&#10007; <?php esc_html_e( 'failed', 'interlink-engine' ); ?></span>
							<?php else : ?>
								<span style="color:#777"><?php esc_html_e( 'waiting to collect', 'interlink-engine' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php
							// NO per-row write button. There is no such thing as
							// writing one post any more — the batch writes the
							// whole campaign and charges for the whole campaign,
							// so a button on one row saying "now" would spend
							// twelve posts' worth of credits. Approving is a
							// campaign-level act with a price on it, and it lives
							// under the table where the price can be shown.
							?>
							<?php if ( 'scheduled' === $slot['status'] ) : ?>
								<a class="button button-small"
								   href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ie_publish_now&campaign=' . rawurlencode( $campaign['id'] ) . '&slot=' . (int) $slot['index'] ), 'ie_publish_now' ) ); ?>">
									<?php esc_html_e( 'Publish now', 'interlink-engine' ); ?>
								</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</details>

			<?php
			/**
			 * Approving, with the price on the button.
			 *
			 * This is the only control on the page that spends money, and it
			 * spends all of it at once: approving a twelve-post campaign is a
			 * 900-credit decision, not a 75-credit one. So the number is on the
			 * button and in the confirmation, not on a screen the owner saw
			 * five minutes ago.
			 *
			 * `$pending` rather than the whole campaign, because a campaign
			 * that half-wrote and stopped costs only what is left.
			 */
			$pending = 0;
			foreach ( $campaign['slots'] as $slot ) {
				if ( 'pending' === $slot['status'] ) {
					$pending++;
				}
			}

			/**
			 * What a post costs, and what to do when we do not know.
			 *
			 * credits_per_post() returns NULL rather than a guess when the
			 * server has not told us — and the accessor matters here, because
			 * IE_Settings::get( 'credits_per_post', 75 ) hands back the stored
			 * null rather than the 75, which would put "0 credits" on a button
			 * that is about to spend nine hundred.
			 *
			 * A guessed price on a spending button is worse than no price: the
			 * owner would have been told a number, and it would be wrong. So
			 * the fallback is to say nothing about cost and let the server's
			 * own refusal be the check.
			 */
			$per_post = IE_Settings::credits_per_post();
			if ( null === $per_post && ! empty( $campaign['quote']['creditsPerPost'] ) ) {
				$per_post = (int) $campaign['quote']['creditsPerPost'];
			}

			$cost = ( null === $per_post ) ? null : $pending * (int) $per_post;

			/**
			 * Has this campaign already been paid for?
			 *
			 * Once it has, the button stops being a purchase and becomes a
			 * status check — the posts are written and charged, and all that
			 * is left is fetching them. Showing a price at that point asks the
			 * owner to decide whether pressing it will cost them again. It
			 * will not, but they have no way to know that from the screen.
			 */
			$approved = ! empty( $campaign['batch_started'] );

			/**
			 * Is the batch recent enough to be worth watching?
			 *
			 * Collection is automatic: the server pings the site and the
			 * plugin takes the posts. So the page has nothing to do but look,
			 * and it only needs to look for as long as a batch plausibly runs
			 * — a minute or so per post. Ten minutes covers a long campaign
			 * with room to spare, and after that a page left open overnight
			 * stops reloading itself forever.
			 */
			$started  = $approved ? strtotime( $campaign['batch_started'] ) : 0;
			$watching = $pending && $approved && $started && ( time() - $started ) < 600;
			?>

			<?php if ( $watching ) : ?>
				<p class="description" style="display:flex;align-items:center;gap:.5rem">
					<span class="spinner is-active" style="float:none;margin:0"></span>
					<?php esc_html_e( 'Writing your posts. They arrive on their own — you can leave this page. This view refreshes itself.', 'interlink-engine' ); ?>
				</p>
				<?php
				// A plain reload, not a re-submitted action. The page is
				// watching, not driving: the server's ping is what actually
				// collects, and re-firing the approve action on a timer would
				// be a very bad way to find that out.
				//
				// Emitted ONCE however many campaigns are mid-batch. Two cards
				// each scheduling a reload gives two timers racing on one
				// document, and the page reloads twice as fast as intended for
				// no reason anyone could see from the screen.
				static $reload_armed = false;

				if ( ! $reload_armed ) {
					$reload_armed = true;
					echo '<script>setTimeout(function () { window.location.reload(); }, 15000);</script>';
				}
				?>
			<?php endif; ?>

			<p style="margin-bottom:0;display:flex;gap:1rem;align-items:center;flex-wrap:wrap">
				<?php if ( $pending && $approved ) : ?>
					<?php
					// Already paid for. No price, no confirmation — this only
					// fetches posts the owner already owns, and it is a
					// fallback for the automatic collection rather than the
					// way the thing is meant to work.
					?>
					<a class="button"
					   href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ie_run_now&campaign=' . rawurlencode( $campaign['id'] ) ), 'ie_run_now' ) ); ?>">
						<?php esc_html_e( 'Check now', 'interlink-engine' ); ?>
					</a>
					<span class="description">
						<?php esc_html_e( 'Already written and paid for. This only fetches them — it costs nothing.', 'interlink-engine' ); ?>
					</span>

				<?php elseif ( $pending ) : ?>
					<a class="button button-primary"
					   href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ie_run_now&campaign=' . rawurlencode( $campaign['id'] ) ), 'ie_run_now' ) ); ?>"
					   onclick="return confirm('<?php echo esc_js(
							null === $cost
								? sprintf(
									/* translators: %d: number of posts */
									__( 'Write %d posts now? They are charged as each one is written.', 'interlink-engine' ),
									$pending
								)
								: sprintf(
									/* translators: 1: number of posts, 2: total credits */
									__( 'Write %1$d posts now? This costs %2$s credits, charged as each post is written.', 'interlink-engine' ),
									$pending, number_format_i18n( $cost )
								)
					   ); ?>')">
						<?php echo esc_html(
							null === $cost
								? sprintf(
									/* translators: %d: number of posts */
									_n( 'Write %d post', 'Write all %d posts', $pending, 'interlink-engine' ),
									$pending
								)
								: sprintf(
									/* translators: 1: number of posts, 2: total credits */
									_n( 'Write %1$d post — %2$s credits', 'Write all %1$d posts — %2$s credits', $pending, 'interlink-engine' ),
									$pending, number_format_i18n( $cost )
								)
						); ?>
					</a>
					<span class="description">
						<?php esc_html_e( 'Every post is written now. They are added to your site dated, and publish on their own days.', 'interlink-engine' ); ?>
					</span>
				<?php endif; ?>

				<a class="button-link-delete" style="margin-left:auto"
				   href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ie_delete_campaign&campaign=' . rawurlencode( $campaign['id'] ) ), 'ie_delete_campaign' ) ); ?>"
				   onclick="return confirm('<?php echo esc_js( __( 'Remove this campaign? Posts already written stay exactly where they are.', 'interlink-engine' ) ); ?>')">
					<?php esc_html_e( 'Remove campaign', 'interlink-engine' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Topics proposed but not yet planned, for the current user.
	 *
	 * Held in a transient rather than an option: it is a half-finished form,
	 * not settings, and if it evaporates the owner presses the button again.
	 */
	private static function draft() {
		$draft = get_transient( self::DRAFT_TRANSIENT . get_current_user_id() );
		return is_array( $draft ) ? $draft : null;
	}

	private static function render_new_campaign_form() {
		$pages    = IE_Settings::target_pages();
		$draft    = self::draft();
		$prefill  = $draft ? $draft['form'] : array();
		$topics   = $draft ? $draft['topics'] : array();
		$warnings = $draft && ! empty( $draft['warnings'] ) ? $draft['warnings'] : array();

		$value = function ( $key, $default = '' ) use ( $prefill ) {
			return isset( $prefill[ $key ] ) ? $prefill[ $key ] : $default;
		};
		?>

		<?php if ( $warnings ) : ?>
			<div class="notice notice-warning inline">
				<p><strong><?php esc_html_e( 'Worth a look before you plan this:', 'interlink-engine' ); ?></strong></p>
				<ul style="list-style:disc;margin-left:1.5rem">
					<?php foreach ( $warnings as $warning ) : ?>
						<li><?php echo esc_html( $warning ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'ie_campaign_form' ); ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="ie_target"><?php esc_html_e( 'Page to rank', 'interlink-engine' ); ?></label></th>
					<td>
						<select name="target_page_id" id="ie_target" required>
							<option value=""><?php esc_html_e( 'Choose a page…', 'interlink-engine' ); ?></option>
							<?php foreach ( $pages as $id => $page ) : ?>
								<option value="<?php echo esc_attr( $id ); ?>" <?php selected( (int) $value( 'target_page_id' ), (int) $id ); ?>>
									<?php echo esc_html( $page['title'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Every post will link to it. Pick the page that books jobs, not a blog page.', 'interlink-engine' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ie_keyword"><?php esc_html_e( 'Its search term', 'interlink-engine' ); ?></label></th>
					<td>
						<input name="keyword" id="ie_keyword" type="text" class="regular-text" required
							value="<?php echo esc_attr( $value( 'keyword' ) ); ?>" placeholder="water heater repair">
						<p class="description"><?php esc_html_e( 'What someone types to find that page. No post will be allowed to compete with it.', 'interlink-engine' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ie_intent"><?php esc_html_e( 'What the reader should end up wanting', 'interlink-engine' ); ?></label></th>
					<td>
						<input name="intent" id="ie_intent" type="text" class="large-text"
							value="<?php echo esc_attr( $value( 'intent' ) ); ?>"
							placeholder="have an existing water heater repaired, rather than replaced">
						<p class="description"><?php esc_html_e( 'A sentence, not a keyword. This is what stops half the posts arguing for the opposite service.', 'interlink-engine' ); ?></p>
					</td>
				</tr>
			</table>

			<?php if ( $topics ) : ?>
				<h3><?php esc_html_e( 'Topics', 'interlink-engine' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Edit anything. Untick one to leave it out. Order is publish order.', 'interlink-engine' ); ?></p>

				<table class="widefat striped" style="margin-bottom:1rem">
					<thead>
						<tr>
							<th style="width:2rem"></th>
							<th><?php esc_html_e( 'Topic', 'interlink-engine' ); ?></th>
							<th><?php esc_html_e( 'Search it should win', 'interlink-engine' ); ?></th>
							<th><?php esc_html_e( 'How other posts refer to it', 'interlink-engine' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $topics as $i => $topic ) : ?>
						<tr>
							<td><input type="checkbox" name="use[<?php echo (int) $i; ?>]" value="1" checked></td>
							<td><input type="text" class="large-text" name="topic[<?php echo (int) $i; ?>]"
								value="<?php echo esc_attr( isset( $topic['topic'] ) ? $topic['topic'] : '' ); ?>"></td>
							<td><input type="text" class="regular-text" name="target_query[<?php echo (int) $i; ?>]"
								value="<?php echo esc_attr( isset( $topic['targetQuery'] ) ? $topic['targetQuery'] : '' ); ?>"></td>
							<td><input type="text" class="regular-text" name="link_phrase[<?php echo (int) $i; ?>]"
								value="<?php echo esc_attr( isset( $topic['linkPhrase'] ) ? $topic['linkPhrase'] : '' ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="ie_topics"><?php esc_html_e( 'Your own topics', 'interlink-engine' ); ?></label></th>
						<td>
							<textarea name="topics" id="ie_topics" rows="8" class="large-text"
								placeholder="<?php esc_attr_e( 'One per line. Or leave empty and press Suggest topics.', 'interlink-engine' ); ?>"></textarea>
							<p class="description"><?php esc_html_e( 'Three to six months worth. Order is publish order.', 'interlink-engine' ); ?></p>
						</td>
					</tr>
				</table>
			<?php endif; ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="ie_cadence"><?php esc_html_e( 'One post every', 'interlink-engine' ); ?></label></th>
					<td>
						<input name="every_days" id="ie_cadence" type="number" min="1" max="90" class="small-text"
							value="<?php echo esc_attr( $value( 'every_days', 14 ) ); ?>">
						<?php esc_html_e( 'days, at', 'interlink-engine' ); ?>
						<input name="publish_time" type="time" value="<?php echo esc_attr( $value( 'publish_time', '09:00' ) ); ?>">
						<p class="description">
							<?php
							printf(
								/* translators: %s: the site's timezone */
								esc_html__( 'Local time (%s). Posts appearing at 3am is the clearest sign a blog is automated.', 'interlink-engine' ),
								esc_html( wp_timezone_string() )
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Once the posts are written', 'interlink-engine' ); ?></th>
					<td>
						<label><input type="radio" name="publish_mode" value="future" <?php checked( 'draft' !== $value( 'publish_mode' ) ); ?>>
							<?php esc_html_e( 'Schedule them, and let WordPress publish each one on its day', 'interlink-engine' ); ?></label><br>
						<label><input type="radio" name="publish_mode" value="draft" <?php checked( 'draft' === $value( 'publish_mode' ) ); ?>>
							<?php esc_html_e( 'Save them all as drafts for me to review', 'interlink-engine' ); ?></label>
						<p class="description"><?php esc_html_e( 'Every post is written the day you approve the campaign. Scheduling is what spreads them out. Drafts are safer, but they depend on you showing up.', 'interlink-engine' ); ?></p>
					</td>
				</tr>
			</table>

			<p class="submit">
				<button type="submit" name="action" value="ie_suggest" class="button">
					<?php echo $topics
						? esc_html__( 'Suggest different topics', 'interlink-engine' )
						: esc_html__( 'Suggest topics for me', 'interlink-engine' ); ?>
				</button>

				<button type="submit" name="action" value="ie_create_campaign" class="button button-primary">
					<?php esc_html_e( 'Plan this campaign', 'interlink-engine' ); ?>
				</button>

				<?php if ( $topics ) : ?>
					<a class="button-link-delete" style="margin-left:1rem"
					   href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ie_discard_draft' ), 'ie_discard_draft' ) ); ?>">
						<?php esc_html_e( 'Start over', 'interlink-engine' ); ?>
					</a>
				<?php endif; ?>
			</p>

			<p class="description">
				<?php esc_html_e( 'Suggesting topics is free. Nothing is charged until a post is actually written.', 'interlink-engine' ); ?>
			</p>
		</form>
		<?php
	}

	/* --------------------------------------------------------------------
	 * Handlers
	 * ----------------------------------------------------------------- */

	/** The shared part of both submit buttons: what the form said about the page. */
	private static function read_form() {
		$page_id = isset( $_POST['target_page_id'] ) ? (int) $_POST['target_page_id'] : 0;
		$page    = $page_id ? get_post( $page_id ) : null;

		if ( ! $page ) {
			return null;
		}

		return array(
			'target_page_id' => $page_id,
			'keyword'        => isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '',
			'intent'         => isset( $_POST['intent'] ) ? sanitize_text_field( wp_unslash( $_POST['intent'] ) ) : '',
			'every_days'     => isset( $_POST['every_days'] ) ? max( 1, min( 90, (int) $_POST['every_days'] ) ) : 14,
			'publish_time'   => isset( $_POST['publish_time'] ) ? sanitize_text_field( wp_unslash( $_POST['publish_time'] ) ) : '09:00',
			// Anything that is not an explicit 'draft' means schedule them. The
			// old value for that was 'publish'; reading it this way round means
			// a form posted by a cached page still does what the owner meant.
			'publish_mode'   => ( isset( $_POST['publish_mode'] ) && 'draft' === $_POST['publish_mode'] ) ? 'draft' : 'future',
			'title'          => get_the_title( $page ),
			'url'            => get_permalink( $page ),
		);
	}

	private static function target_page_payload( $form ) {
		return array(
			'url'     => $form['url'],
			'keyword' => $form['keyword'],
			'title'   => $form['title'],
			'intent'  => $form['intent'],
		);
	}

	public static function handle_suggest() {
		check_admin_referer( 'ie_campaign_form' );
		self::require_caps();

		$form = self::read_form();
		if ( ! $form ) {
			self::redirect( 'interlink-engine', 'error', __( 'Choose a page for the campaign to feed.', 'interlink-engine' ) );
		}

		// Topics already on screen are what NOT to propose again, so pressing
		// the button twice gives a different set rather than the same one.
		$draft = self::draft();
		$avoid = array();
		if ( $draft && ! empty( $draft['topics'] ) ) {
			$avoid = wp_list_pluck( $draft['topics'], 'topic' );
		}

		$result = IE_Api::suggest( self::target_page_payload( $form ), 6, $avoid );

		if ( is_wp_error( $result ) ) {
			self::redirect( 'interlink-engine', 'error', $result->get_error_message() );
		}

		set_transient(
			self::DRAFT_TRANSIENT . get_current_user_id(),
			array(
				'form'     => $form,
				'topics'   => isset( $result['topics'] ) ? $result['topics'] : array(),
				'warnings' => isset( $result['warnings'] ) ? $result['warnings'] : array(),
			),
			DAY_IN_SECONDS
		);

		self::redirect( 'interlink-engine', 'suggested', '' );
	}

	public static function handle_create_campaign() {
		check_admin_referer( 'ie_campaign_form' );
		self::require_caps();

		$form = self::read_form();
		if ( ! $form ) {
			self::redirect( 'interlink-engine', 'error', __( 'Choose a page for the campaign to feed.', 'interlink-engine' ) );
		}

		$target_page = self::target_page_payload( $form );
		$topics      = self::collect_topics();

		if ( empty( $topics ) ) {
			self::redirect( 'interlink-engine', 'error', __( 'Add some topics, or press Suggest topics.', 'interlink-engine' ) );
		}

		// A topic typed by hand has no target query, and planning refuses one
		// without it. Derived here rather than leaving the owner to meet that
		// refusal cold.
		$missing = array_filter( $topics, function ( $t ) {
			return empty( $t['targetQuery'] );
		} );

		if ( $missing ) {
			$enriched = IE_Api::enrich(
				$target_page,
				wp_list_pluck( $missing, 'topic' ),
				array_values( array_filter( $topics, function ( $t ) {
					return ! empty( $t['targetQuery'] );
				} ) )
			);

			if ( is_wp_error( $enriched ) ) {
				self::redirect( 'interlink-engine', 'error', $enriched->get_error_message() );
			}

			$by_topic = array();
			foreach ( (array) $enriched['topics'] as $t ) {
				$by_topic[ $t['topic'] ] = $t;
			}

			foreach ( $topics as $i => $t ) {
				if ( empty( $t['targetQuery'] ) && isset( $by_topic[ $t['topic'] ] ) ) {
					$topics[ $i ] = $by_topic[ $t['topic'] ];
				}
			}
		}

		$plan = IE_Api::plan( array(
			'name'       => $form['title'],
			'targetPage' => $target_page,
			'topics'     => array_values( $topics ),
			'linkMode'   => 'standalone',
			'schedule'   => array(
				'everyDays'   => $form['every_days'],
				'publishTime' => $form['publish_time'],
				// The server turns cadence plus wall-clock time into real
				// instants, and needs the zone to do it — 09:00 has to mean
				// nine in the morning where the business is.
				'timezone'    => wp_timezone_string(),
			),
		) );

		if ( is_wp_error( $plan ) ) {
			self::redirect( 'interlink-engine', 'error', $plan->get_error_message() );
		}

		$campaign = IE_Campaigns::create_from_plan( $plan, array(
			'label'        => $form['title'],
			'every_days'   => $form['every_days'],
			'publish_mode' => $form['publish_mode'],
			'target_page'  => array(
				'id'      => $form['target_page_id'],
				'title'   => $form['title'],
				'url'     => $form['url'],
				'keyword' => $form['keyword'],
				'intent'  => $form['intent'],
			),
		) );

		if ( is_wp_error( $campaign ) ) {
			self::redirect( 'interlink-engine', 'error', $campaign->get_error_message() );
		}

		delete_transient( self::DRAFT_TRANSIENT . get_current_user_id() );

		IE_Publisher::log( sprintf(
			'campaign %s planned: %d posts feeding "%s"',
			$campaign['id'], count( $campaign['slots'] ), $form['title']
		) );

		$note = '';
		if ( ! empty( $plan['warnings'] ) ) {
			$note = implode( ' · ', array_map( 'strval', (array) $plan['warnings'] ) );
		}
		if ( isset( $plan['enoughCredits'] ) && ! $plan['enoughCredits'] ) {
			$note = trim( $note . ' ' . __( 'Not enough credits for the whole batch — posts will pause when the balance runs out.', 'interlink-engine' ) );
		}

		self::redirect( 'interlink-engine', 'planned', $note );
	}

	/**
	 * Topics from whichever form was on screen.
	 *
	 * The edit table when suggestions were shown, the textarea otherwise. The
	 * table carries the queries and link phrases already; the textarea gives
	 * bare lines that enrichment will complete.
	 */
	private static function collect_topics() {
		$topics = array();

		if ( ! empty( $_POST['topic'] ) && is_array( $_POST['topic'] ) ) {
			$use = isset( $_POST['use'] ) && is_array( $_POST['use'] ) ? $_POST['use'] : array();

			foreach ( $_POST['topic'] as $i => $raw ) {
				if ( ! isset( $use[ $i ] ) ) {
					continue;   // unticked
				}

				$topic = sanitize_text_field( wp_unslash( $raw ) );
				if ( '' === $topic ) {
					continue;
				}

				$topics[] = array(
					'topic'       => $topic,
					'targetQuery' => isset( $_POST['target_query'][ $i ] ) ? sanitize_text_field( wp_unslash( $_POST['target_query'][ $i ] ) ) : '',
					'linkPhrase'  => isset( $_POST['link_phrase'][ $i ] ) ? sanitize_text_field( wp_unslash( $_POST['link_phrase'][ $i ] ) ) : '',
				);
			}

			return $topics;
		}

		$raw = isset( $_POST['topics'] ) ? sanitize_textarea_field( wp_unslash( $_POST['topics'] ) ) : '';

		foreach ( array_filter( array_map( 'trim', preg_split( '/\R/', $raw ) ) ) as $line ) {
			$topics[] = array( 'topic' => $line, 'targetQuery' => '', 'linkPhrase' => '' );
		}

		return $topics;
	}

	public static function handle_discard_draft() {
		check_admin_referer( 'ie_discard_draft' );
		self::require_caps();

		delete_transient( self::DRAFT_TRANSIENT . get_current_user_id() );
		self::redirect( 'interlink-engine', 'discarded', '' );
	}

	/**
	 * Approve a campaign, or move it along.
	 *
	 * One button rather than one per slot, because there is no longer such a
	 * thing as writing a single post: the whole campaign is written in one
	 * batch. Pressing this repeatedly is safe — it starts the batch, then
	 * reports on it, then collects.
	 */
	public static function handle_run_now() {
		check_admin_referer( 'ie_run_now' );
		self::require_caps();

		$campaign_id = isset( $_GET['campaign'] ) ? sanitize_text_field( wp_unslash( $_GET['campaign'] ) ) : '';

		$result = IE_Publisher::run_campaign( $campaign_id );

		if ( is_wp_error( $result ) ) {
			self::redirect( 'interlink-engine', 'error', $result->get_error_message() );
		}

		// Still writing. Not a failure, and said plainly so nobody presses the
		// button again thinking nothing happened.
		if ( ! empty( $result['writing'] ) ) {
			self::redirect( 'interlink-engine', 'writing', sprintf(
				/* translators: 1: posts written so far, 2: total */
				__( '%1$d of %2$d written so far.', 'interlink-engine' ),
				(int) $result['done'], (int) $result['total']
			) );
		}

		self::redirect( 'interlink-engine', 'scheduled', sprintf(
			/* translators: %d: number of posts added to the site */
			_n( '%d post added.', '%d posts added.', (int) $result['inserted'], 'interlink-engine' ),
			(int) $result['inserted']
		) );
	}

	/**
	 * Publish one scheduled post immediately.
	 *
	 * For the owner who does not want to wait for a date — and, more usefully,
	 * for the site whose WP-Cron is not running. Everything downstream happens
	 * through IE_Publisher::on_transition() exactly as if cron had fired.
	 */
	public static function handle_publish_now() {
		check_admin_referer( 'ie_publish_now' );
		self::require_caps();

		$campaign_id = isset( $_GET['campaign'] ) ? sanitize_text_field( wp_unslash( $_GET['campaign'] ) ) : '';
		$slot_index  = isset( $_GET['slot'] ) ? (int) $_GET['slot'] : -1;

		$campaign = IE_Campaigns::get( $campaign_id );
		$found    = $campaign ? IE_Campaigns::find_slot( $campaign, $slot_index ) : null;

		if ( ! $found || empty( $found[1]['post_id'] ) ) {
			self::redirect( 'interlink-engine', 'error', __( 'That post could not be found.', 'interlink-engine' ) );
		}

		// publish_now(), not wp_publish_post(): this post is dated in the future
		// and the owner is choosing to publish it early, so the date has to move
		// to now — otherwise it goes live claiming to be from next Thursday.
		$result = IE_Publisher::publish_now( (int) $found[1]['post_id'] );

		if ( is_wp_error( $result ) ) {
			self::redirect( 'interlink-engine', 'error', $result->get_error_message() );
		}

		self::redirect( 'interlink-engine', 'published', '' );
	}

	public static function handle_delete_campaign() {
		check_admin_referer( 'ie_delete_campaign' );
		self::require_caps();

		$campaign_id = isset( $_GET['campaign'] ) ? sanitize_text_field( wp_unslash( $_GET['campaign'] ) ) : '';
		IE_Campaigns::delete( $campaign_id );

		self::redirect( 'interlink-engine', 'removed', '' );
	}

	/* --------------------------------------------------------------------
	 * Bits
	 * ----------------------------------------------------------------- */

	private static function require_caps() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'interlink-engine' ) );
		}
	}

	private static function redirect( $page, $status, $message ) {
		wp_safe_redirect( add_query_arg(
			array(
				'page'       => $page,
				'ie_status'  => $status,
				'ie_message' => rawurlencode( $message ),
			),
			admin_url( 'admin.php' )
		) );
		exit;
	}

	private static function notices() {
		if ( empty( $_GET['ie_status'] ) ) {
			return;
		}

		$status  = sanitize_text_field( wp_unslash( $_GET['ie_status'] ) );
		$message = isset( $_GET['ie_message'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['ie_message'] ) ) ) : '';

		$map = array(
			'connected'    => array( 'success', __( 'Connected.', 'interlink-engine' ) ),
			'server_saved' => array( 'success', __( 'Server address saved. Your connection was left alone.', 'interlink-engine' ) ),
			'unchanged'    => array( 'info', __( 'Nothing to change — that is already the address.', 'interlink-engine' ) ),
			'suggested' => array( 'success', __( 'Here are some topics. Edit anything, untick what you do not want, then plan the campaign.', 'interlink-engine' ) ),
			// Does not name the button. The button carries the post count and
			// the price ("Write all 3 posts — 225 credits"), so any wording
			// here that tries to quote it goes stale the moment either changes
			// — which is exactly how this notice came to say "press Collect
			// now" while the button said something else entirely.
			'planned'   => array( 'success', __( 'Campaign planned and saved as a draft. Nothing has been charged yet — approve it below and every post is written at once.', 'interlink-engine' ) ),
			'scheduled' => array( 'success', __( 'Added to your site, dated. WordPress will publish them on their days, and the links switch on as each one goes live.', 'interlink-engine' ) ),
			'published' => array( 'success', __( 'Published, and every post waiting on it now links to it.', 'interlink-engine' ) ),
			// Says the true thing: there is nothing for the owner to do. The
			// server pings the site when the batch finishes and the posts
			// collect themselves. The old wording left people watching a
			// static page wondering when to press something.
			'writing'   => array( 'info', __( 'Writing your posts now — about a minute each. They will appear on their own; you do not need to do anything, and you can leave this page.', 'interlink-engine' ) ),
			'removed'   => array( 'success', __( 'Campaign removed. The posts it wrote are untouched.', 'interlink-engine' ) ),
			'discarded' => array( 'info', __( 'Draft topics discarded.', 'interlink-engine' ) ),
			'error'     => array( 'error', __( 'That did not work.', 'interlink-engine' ) ),
		);

		if ( ! isset( $map[ $status ] ) ) {
			return;
		}

		list( $type, $text ) = $map[ $status ];

		printf(
			'<div class="notice notice-%s is-dismissible"><p>%s%s</p></div>',
			esc_attr( $type ),
			esc_html( $text ),
			$message ? ' ' . esc_html( $message ) : ''
		);
	}

	private static function render_log() {
		$log = IE_Publisher::get_log();

		if ( empty( $log ) ) {
			echo '<p>' . esc_html__( 'Nothing yet.', 'interlink-engine' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><tbody>';
		foreach ( array_slice( $log, 0, 15 ) as $entry ) {
			printf(
				'<tr><td style="width:12rem;color:#666">%s</td><td>%s</td></tr>',
				esc_html( $entry['at'] ),
				esc_html( $entry['message'] )
			);
		}
		echo '</tbody></table>';
	}
}
